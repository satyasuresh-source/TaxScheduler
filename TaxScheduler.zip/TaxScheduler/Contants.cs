﻿namespace TaxScheduler
{
    public static class Contants
    {
        public const string FilePath = "CSV";
        public const string FileName = "E:\\Municipality.CSV";
        public const string URL = "http://localhost:51547";        
    }
}
