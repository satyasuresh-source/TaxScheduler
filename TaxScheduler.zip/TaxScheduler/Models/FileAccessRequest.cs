﻿namespace TaxScheduler.Models
{
   public class FileAccessRequest
    {      
        public string FileType { get; set; }
     
        public string FilePath { get; set; }

    }
}
